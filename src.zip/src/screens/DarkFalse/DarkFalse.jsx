import React from "react";
import { Screen } from "../../components/Screen";

export const DarkFalse = () => {
  return <Screen dark="false" />;
};
