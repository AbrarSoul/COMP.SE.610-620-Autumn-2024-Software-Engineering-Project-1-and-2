export { IconlyLightOutlineUpload2 } from "./IconlyLightOutlineUpload2";
