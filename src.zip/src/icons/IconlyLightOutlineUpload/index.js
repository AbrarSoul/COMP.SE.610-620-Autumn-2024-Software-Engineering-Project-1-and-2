export { IconlyLightOutlineUpload } from "./IconlyLightOutlineUpload";
