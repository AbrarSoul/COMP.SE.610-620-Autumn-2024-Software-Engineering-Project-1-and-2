export { IconlyLightOutlineUpload1 } from "./IconlyLightOutlineUpload1";
