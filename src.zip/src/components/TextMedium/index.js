export { TextMedium } from "./TextMedium";
