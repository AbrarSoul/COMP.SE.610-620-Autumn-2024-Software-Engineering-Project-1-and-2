import { IconlyLightOutline } from ".";

export default {
  title: "Components/IconlyLightOutline",
  component: IconlyLightOutline,
};

export const Default = {
  args: {
    className: {},
  },
};
