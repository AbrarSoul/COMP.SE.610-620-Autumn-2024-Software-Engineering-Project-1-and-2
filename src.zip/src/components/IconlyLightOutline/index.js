export { IconlyLightOutline } from "./IconlyLightOutline";
